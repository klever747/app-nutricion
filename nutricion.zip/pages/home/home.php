<!-- HOME -->
     <section id="home">
          <div class="row">

                    <div class="owl-carousel owl-theme home-slider">
                         <div class="item item-first">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1>El software de nutrición para dietistas y nutricionistas</h1>
                                             <h3>QUIPANUTRI es un software que permite agilizar el proceso de evaluación nutricional del paciente.</h3>
                                             <a href="account" class="section-btn btn btn-default smoothScroll">Registrate gratis</a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-second">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1>El software de nutrición para dietistas y nutricionistas</h1>
                                             <h3>QUIPANUTRI es un software que permite agilizar el proceso de evaluación nutricional del paciente.</h3>
                                            <a onclick="AbrirModalsRegistroPaciente()" class="section-btn btn btn-default smoothScroll">Registrate gratis</a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-third">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                            <h1>El software de nutrición para dietistas y nutricionistas</h1>
                                             <h3>QUIPANUTRI es un software que permite agilizar el proceso de evaluación nutricional del paciente.</h3>
                                            <a onclick="AbrirModalsRegistroPaciente()" class="section-btn btn btn-default smoothScroll">Registrate gratis</a>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
          </div>
     </section>