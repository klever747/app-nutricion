<!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-lg-4">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Secciones</h2>
                                    <ul>
                                        <li><a href="#feature">Funcionalidades</a></li>
                                        <li><a href="#team">Quienes somos</a></li>
                                        <li><a href="#courses">Beneficios</a></li>
                                        <li><a href="#">Login</a></li>
                                   </ul>

                              </div>


                         </div>
                    </div>

                    <div class="col-lg-4">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Más información</h2>
                              </div>
                              <address>
                                   <p>+0989761198, +0989574272</p>
                                   <p><a href="correro:">quipanutri@gmail.com</a></p>
                              </address>
                         </div>
                    </div>
                     <div class="col-lg-4">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Sobre Quipanutri</h2>
                              </div>
                              <address>
                                   <p>Es un software para nutricionistas y dietistas gratuito sin licencia.</p>
                                   <p>Somos un grupo de profesionales de la Escuela Superior Politécnica de Chimborazo en busca de soluciones para el seguimiento adecuado de un paciente en sus dietas nutricionales.</p>
                              </address>
                         </div>
                    </div>
                    <div class="col-lg-12" style="text-align: center;">
                          <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>

                              <div class="copyright-text">
                                   <p>Copyright &copy; 2021</p>

                                   <p>  Ecuador 2021</p>
                              </div>

                    </div>
               </div>
          </div>
     </footer>